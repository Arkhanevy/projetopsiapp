<?php

namespace models;

use core\database\DBQuery;
use core\database\Where;
use core\database\DBConnection;

class busca {
    private $table = '';
    private  $campos = [];
    private  $primary = '';
    
    public function __construct($table,$campos,$primary) {
        $this->table = $table;
        $this->campos = $campos;
        $this->primary = $primary;
    }
    public function Buscar($busca,$valor,$pro){
        $camposStr = implode(',',$this->campos);
        $where = new Where();
        if ($this->table != 'servico' && $this->table != 'profissional' && $this->table != 'clinica') {
            return ['sucesso' => false, 'mensagem' => 'tipo de busca invalida'];
        }
        if ($this->table === 'servico') {
            
            if ($valor !== null && $valor !== '') {
                
                $grupo = new Where();
                
                $grupo->addCondition('AND', 'ser_val', '=', $valor);
                $grupo->addLike('AND', 'ser_nome', $busca);
                
                $grupo->addCondition('OR', 'ser_val', '=', $valor);
                $grupo->addLike('AND', 'ser_tipo', $busca);
                
                $where->addGroup('AND', $grupo);
                $where->addCondition('AND', 'ser_stat', '=', 'ativo');
                
            } else {
                
                $grupo = new Where();
                
                $grupo->addLike('AND', 'ser_nome', $busca);
                $grupo->addLike('OR', 'ser_tipo', $busca);
                
                $where->addGroup('AND', $grupo);
                $where->addCondition('AND', 'ser_stat', '=', 'ativo');
            }
            
            $where = $where->buildGroup();
            
        } else {
            if ($this->table === 'profissional') {
                if (!empty($pro)) {
                    $where->addCondition('AND', 'ser_pro', '=', $pro);
                }else {$where->addLike('AND', 'pro_nome', $busca);}
                $where = $where->build();
            }
            if ($this->table === 'clinica') {
                $where->addLike('AND', 'clin_nome', $busca);
                $where = $where->build();
            }  
            
        }
           
        $mostrar = new DBQuery($this->table, $camposStr,$this->primary);
        try {
            $resultado = $mostrar->selectWhere($where);
            
            if ($resultado) {
                return [
                    'sucesso' => true,
                    'dados' => $resultado->fetchAll(\PDO::FETCH_ASSOC)
                ];
            }else {
                return [
                    'sucesso' => false,
                    'erro' => 'Erro ao resgatar informação'
                ];
            }
        } catch (\InvalidArgumentException $e) {
            return [
                'sucesso' => false,
                'erro' => 'Erro de validação: ' . $e->getMessage()
            ];
        } catch (\Exception $e) {
            return [
                'sucesso' => false,
                'erro' => 'Erro no banco: ' . $e->getMessage()
            ];
        }
    }
    
    public function MostrarDetalhes($id) {
        $camposStr = implode(',',$this->campos);
        $mostrar = new DBQuery($this->table, $camposStr,$this->primary );
        $where = new Where();
        if ($this->table === 'servico') {
            $where->addCondition('AND', 'ser_id', '=',$id);
            $where->addCondition('AND', 'ser_stat', '=','ativo');
        }
        if ($this->table === 'profissional') {
            $where->addCondition('AND', 'pro_id', '=',$id);
        }
        if ($this->table === 'clinica') {
            $where->addCondition('AND', 'clin_id', '=',$id);
        }
        
        $where = $where->build();
        try {
            $resultado = $mostrar->selectWhere($where);
            
            if ($resultado) {
                return [
                    'sucesso' => true,
                    'dados' => $resultado->fetchAll(\PDO::FETCH_ASSOC)
                ];
            }else {
                return [
                    'sucesso' => false,
                    'erro' => 'Erro ao resgatar informação'
                ];
            }
        } catch (\InvalidArgumentException $e) {
            return [
                'sucesso' => false,
                'erro' => 'Erro de validação: ' . $e->getMessage()
            ];
        } catch (\Exception $e) {
            return [
                'sucesso' => false,
                'erro' => 'Erro no banco: ' . $e->getMessage()
            ];
        }
    }
    
    // Serviços ativos de um perfil, para quem visita (não depende de sessão do dono).
    public function ServicosPublicos($tipo,$id) {
        if ($tipo !== 'profissional' && $tipo !== 'clinica') {
            return [];
        }
        $coluna = $tipo === 'clinica' ? 'ser_clin' : 'ser_pro';
        try {
            $pdo = (new DBConnection())->getConn();
            $st = $pdo->prepare("SELECT s.ser_id, s.ser_pro, s.ser_clin, s.ser_nome, s.ser_tipo, s.ser_desc, s.ser_dur, s.ser_inter, s.ser_val, s.ser_dia, s.ser_loc, p.pro_nome
                FROM servico s LEFT JOIN profissional p ON p.pro_id = s.ser_pro
                WHERE s.$coluna = :id AND s.ser_stat = 'ativo' ORDER BY s.ser_nome");
            $st->execute([':id' => (int) $id]);
            return $st->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Throwable $e) {
            return [];
        }
    }

    // Localizações da clínica visíveis a quem visita. A residência do profissional nunca é exposta aqui.
    public function LocalizacoesPublicas($tipo,$id) {
        if ($tipo !== 'clinica') {
            return [];
        }
        try {
            $pdo = (new DBConnection())->getConn();
            $st = $pdo->prepare("SELECT loc_id, loc_nome, loc_tipo, loc_cep, loc_num, loc_compl FROM localizacao WHERE loc_clin = :id ORDER BY loc_id");
            $st->execute([':id' => (int) $id]);
            return $st->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Throwable $e) {
            return [];
        }
    }

    public function MeusServicos($usuario,$id) {
        $camposServ = implode(',',$this->campos);
        try {
            $mostrar = new DBQuery($this->table, $camposServ,$this->primary );
            $where = new Where();
            if ($usuario === 'profissional') {
                $cod = 'ser_pro';
            }
            else if ($usuario === 'clinica') {
                $cod = 'ser_clin';
            }
            else {return ['sucesso' => false,'mensagem' => 'cliente não tem serviço'];}
            $where->addCondition('AND', $cod, '=',$id);
            $where = $where->build();
            $resultado = $mostrar->selectWhere($where);
            
            if ($resultado) {
                return [
                    'sucesso' => true,
                    'dados' => $resultado->fetchAll(\PDO::FETCH_ASSOC)
                ];
            }else {
                return [
                    'sucesso' => false,
                    'erro' => 'Erro ao resgatar informação'
                ];
            }
        } catch (\InvalidArgumentException $e) {
            return [
                'sucesso' => false,
                'erro' => 'Erro de validação: ' . $e->getMessage()
            ];
        } catch (\Exception $e) {
            return [
                'sucesso' => false,
                'erro' => 'Erro no banco: ' . $e->getMessage()
            ];
        }
    }
    
    private function camposGerenciar() {
        $prefixo = 'pro_';
        $tabela = 'profissional';

        
        return implode(', ', array_map(function ($campo) use ($prefixo,$tabela) {
            
            if (strpos($campo, '.') !== false) {
                return $campo;
            }
            if (strpos($campo, $prefixo) === 0) {
                    return $tabela . '.' . $campo;
                }
            
            
            return $campo;
        }, $this->campos));
    }
    
    
    public function gerenciarPro($clin) {
        $camposStr = $this->camposGerenciar();
        $profissional = new DBQuery('profissional','pro_id,','pro_id');
        $pc= new DBQuery('profissional_clinica', $camposStr, 'pc_id');
        
        $pc->addJoin('INNER', 'pc_pro', $profissional, 'pro_id');
        
        $where = new Where();
        
        $where->addCondition('AND', 'pc_clin', '=',$clin);


        try {
            $resultado = $pc->selectFiltered($where);
            
            if ($resultado) {
                return [
                    'sucesso' => true,
                    'dados' => $resultado->fetchAll(\PDO::FETCH_ASSOC)
                ];
            }else {
                return [
                    'sucesso' => false,
                    'erro' => 'Erro ao resgatar informação'
                ];
            }
        } catch (\InvalidArgumentException $e) {
            return [
                'sucesso' => false,
                'erro' => 'Erro de validação: ' . $e->getMessage()
            ];
        } catch (\Exception $e) {
            return [
                'sucesso' => false,
                'erro' => 'Erro no banco: ' . $e->getMessage()
            ];
        }
    }
    
    public function permiçãoPro($pc) {
        $camposServ = implode(',',$this->campos);
        $mostrar = new DBQuery($this->table, $camposServ,$this->primary );
        $where = new Where();
        $where->addCondition('AND', 'perm_pc', '=',$pc);
        $where = $where->build();
            try {
                $resultado = $mostrar->selectWhere($where);
            
                if ($resultado) {
                    return [
                        'sucesso' => true,
                        'dados' => $resultado->fetchAll(\PDO::FETCH_ASSOC)
                    ];
                }else {
                    return [
                        'sucesso' => false,
                        'erro' => 'Erro ao resgatar informação'
                    ];
                }
        } catch (\InvalidArgumentException $e) {
            return [
                'sucesso' => false,
                'erro' => 'Erro de validação: ' . $e->getMessage()
            ];
        } catch (\Exception $e) {
            return [
                'sucesso' => false,
                'erro' => 'Erro no banco: ' . $e->getMessage()
            ];
        }
    }
    
    
}