<?php
namespace models;

use core\database\DBQuery;
use core\database\DBConnection;
use core\database\Where;

class localizacao {
    private $campos =[];
    private $primarykey =[];
    private $table = '';
    
    public function __construct($table,$campos,$primary) {
        $this->table = $table;
        $this->campos = $campos;
        $this->primary = $primary;
    }
    
    private function contruircampos($prefixo,$usuario) {
        $mapa = [
            'profissional' => 'pro',
            'clinica'      => 'clin',
            'cliente'      => 'cli',
        ];
        return $prefixo.$mapa[$usuario];}

    private function verifica($usuario,$id,$loc) {
        $cod = $this->contruircampos('loc_', $usuario);

        $camposStr = $this->table === 'localizacao' ? implode(',', $this->campos) : 'loc_id';
        
        $verifica = new DBQuery('localizacao', $camposStr, 'loc_id');
        $where = new Where();
        $where->addCondition('AND', 'loc_id', '=',$loc);
        $where->addCondition('AND', $cod, '=',$id);
        $where = $where->build();
        try {
            $resultado = $verifica->selectWhere($where);
            $dono = $resultado->fetch(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            return [
                'sucesso' => false,
                'mensagem' => $e->getMessage()
            ];
            
        };
        if (!$dono) {
            return [
                'sucesso' => false,
                'mensagem' => "você não é o dono dessa localização"];
        }
        return ['sucesso' => true];
        
    }
    public function inserirloc($pro,$clin,$nome,$tipo,$cep,$num,$comp) {
        $camposLoc = implode(',',$this->campos);
        $dados =[
            0,
            $pro,
            $clin,
            $nome,
            $tipo,
            $cep,
            $num,
            $comp
        ];
        try {
            $cadastrar = new DBQuery($this->table, $camposLoc,$this->primarykey );
            $resultado = $cadastrar->insert($dados);
            
            if ($resultado) {
                if ($tipo === 'casa' && $pro !== null) {
                    $this->criarSalaPadrao($pro);
                }
                return ["sucesso" => true];
            } else {
                return ["sucesso" => false, 'mensagem' => "erro ao inserir"];
            }
        } catch (\InvalidArgumentException $e) {
            return ["sucesso" =>false, 'mensagem' => "Erro de validação: " . $e->getMessage()];
        } catch (\Exception $e) {
            return ["sucesso" => false, 'mensagem' => "Erro no banco: " . $e->getMessage()];
        };
    }
    
    public function inserirsala($loc,$nome,$usuario,$id) {
        $dono = $this->verifica($usuario, $id, $loc);
        if ($dono['sucesso'] === false){
            return $dono;
        }
        $camposSala = implode(',',$this->campos);
        $dados =[
            0,
            $loc,
            $nome
        ];
        try {
            $cadastrar = new DBQuery($this->table, $camposSala,$this->primarykey );
            $resultado = $cadastrar->insert($dados);
            
            if ($resultado) {
                return ["sucesso" => true];
            } else {
                return ["sucesso" => false, 'mensagem' => "erro ao inserir"];
            }
        } catch (\InvalidArgumentException $e) {
            return ["sucesso" => false, 'mensagem' => "Erro de validação: " . $e->getMessage()];
        } catch (\Exception $e) {
            return ["sucesso" => false, 'mensagem' => "Erro no banco: " . $e->getMessage()];
        };
    }
    
    public function pegarloc($dono,$id,$publico = false) {
        $camposLoc = implode(',',$this->campos);
        $cod = $this->contruircampos('loc_',$dono);
        $mostrar = new DBQuery($this->table, $camposLoc,$this->primarykey);
        $where = new Where();
        $where->addCondition('AND', $cod,'=', $id);
        $where = $where->build();
        try{
            $resultado = $mostrar->selectWhere($where);
            
            if ($resultado) {
                $dados = $resultado->fetchAll(\PDO::FETCH_ASSOC);
                if ($publico) {
                    // endereço da residência do profissional nunca é exposto a terceiros
                    $dados = array_values(array_filter($dados, function ($loc) {
                        return $loc['loc_tipo'] !== 'casa';
                    }));
                }
                return ['sucesso' => true, 'dados' => $dados];
            }else {
                return ['sucesso' => false,
                    'mensagem' => 'Erro ao resgatar informação'];
            }
        } catch (\InvalidArgumentException $e) {
            return ['sucesso' => false,
                'mensagem' => 'Erro de validação: ' . $e->getMessage()];
        } catch (\Exception $e) {
            return ['sucesso' => false,
                'mensagem' => 'Erro no banco: ' . $e->getMessage()];
        }
    }

    public function pegarSalas($loc){
        $camposLoc = implode(',',$this->campos);
        $mostrar = new DBQuery($this->table, $camposLoc,$this->primarykey);
        $where = new Where();
        $where->addCondition('AND', 'sala_loc','=', $loc);
        $where = $where->build();
        try{
            $resultado = $mostrar->selectWhere($where);
            
            if ($resultado) {
                return ['sucesso' => true,
                    'dados' =>$resultado->fetchAll(\PDO::FETCH_ASSOC)];
            }else {
                return ['sucesso' => false,
                    'mensagem' => 'Erro ao resgatar informação'];
            }
        } catch (\InvalidArgumentException $e) {
            return ['sucesso' => false,
                'mensagem' => 'Erro de validação: ' . $e->getMessage()];
        } catch (\Exception $e) {
            return ['sucesso' => false,
                'mensagem' => 'Erro no banco: ' . $e->getMessage()];
        }
    }
    
    // O agendamento sempre escolhe uma sala (agnd_sala) para serviços com localização.
    // A residência do profissional nasce com uma sala padrão, para o agendamento funcionar sem cadastro manual de sala.
    private function criarSalaPadrao($pro) {
        try {
            $pdo = (new DBConnection())->getConn();
            $st = $pdo->prepare("SELECT loc_id FROM localizacao WHERE loc_pro = :pro AND loc_tipo = 'casa' ORDER BY loc_id DESC LIMIT 1");
            $st->execute([':pro' => (int) $pro]);
            $loc = $st->fetchColumn();
            if (!$loc) {
                return;
            }
            $st = $pdo->prepare("SELECT COUNT(*) FROM sala WHERE sala_loc = :loc");
            $st->execute([':loc' => (int) $loc]);
            if ((int) $st->fetchColumn() > 0) {
                return;
            }
            $pdo->prepare("INSERT INTO sala (sala_loc, sala_nome) VALUES (:loc, 'Residência')")->execute([':loc' => (int) $loc]);
        } catch (\Throwable $e) {
            // sem sala padrão o cadastro da localização continua valendo
        }
    }

    public function editar($dados,$usuario,$id) {
        if (!is_array($dados) || empty($dados)) {
            return ['sucesso' => false, 'mensagem' => 'Dados inválidos'];
        }
        $loc = $dados[0];
        if ($this->table === 'sala') {
            // a sala só pode ser editada por quem é dono da localização dela
            try {
                $pdo = (new DBConnection())->getConn();
                $st = $pdo->prepare("SELECT sala_loc FROM sala WHERE sala_id = :sala");
                $st->execute([':sala' => (int) $dados[0]]);
                $loc = $st->fetchColumn();
            } catch (\Throwable $e) {
                return ['sucesso' => false, 'mensagem' => $e->getMessage()];
            }
            if ($loc === false) {
                return ['sucesso' => false, 'mensagem' => 'Sala não encontrada'];
            }
        }
        $dono = $this->verifica($usuario, $id, $loc);
        if ($dono['sucesso'] === false) {
            return $dono;
        }

        $camposStr = implode(',', $this->campos);
        $ativar =  new DBQuery($this->table, $camposStr, $this->primary);
        try {
            $Update = $ativar->update($dados);
            if ($Update) {
                return ['sucesso' => true];
            } else {
                return ['sucesso' => false, 'mensagem' => "erro ao atualizar"];
            }
        }
        catch (\Exception $e) {
            return ['sucesso' => false, 'mensagem' => $e->getMessage()];
        }
    }

    // remove a localização "casa" do profissional (desativa o atendimento na residência)
    public function removerloc($usuario,$id,$loc) {
        $dono = $this->verifica($usuario, $id, $loc);
        if ($dono['sucesso'] === false) {
            return $dono;
        }
        try {
            $pdo = (new DBConnection())->getConn();
            $st = $pdo->prepare("SELECT loc_tipo FROM localizacao WHERE loc_id = :loc");
            $st->execute([':loc' => (int) $loc]);
            if ($st->fetchColumn() !== 'casa') {
                return ['sucesso' => false, 'mensagem' => 'Apenas a localização da residência pode ser removida por aqui.'];
            }
            $st = $pdo->prepare("SELECT COUNT(*) FROM servico WHERE ser_loc = :loc AND ser_stat = 'ativo'");
            $st->execute([':loc' => (int) $loc]);
            if ((int) $st->fetchColumn() > 0) {
                return ['sucesso' => false, 'mensagem' => 'Existem serviços ativos atendendo na sua residência. Remova-os antes de desativar.'];
            }
            $pdo->beginTransaction();
            try {
                $pdo->prepare("DELETE FROM sala WHERE sala_loc = :loc")->execute([':loc' => (int) $loc]);
                $pdo->prepare("DELETE FROM localizacao WHERE loc_id = :loc")->execute([':loc' => (int) $loc]);
                $pdo->commit();
            } catch (\Throwable $e) {
                $pdo->rollBack();
                return ['sucesso' => false, 'mensagem' => 'Existem agendamentos nessa residência, por isso ela não pode ser removida.'];
            }
            return ['sucesso' => true];
        } catch (\Throwable $e) {
            return ['sucesso' => false, 'mensagem' => $e->getMessage()];
        }
    }
}
