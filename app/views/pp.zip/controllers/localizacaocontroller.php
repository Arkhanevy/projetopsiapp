<?php
use models\localizacao;

function responderLocalizacao($resposta) {
    echo json_encode($resposta);
    exit;
}

$acao = $_POST['acao'] ?? '';
$tipoUsuario = $_SESSION['usuario']['tipoUsuario'] ?? '';
$idUsuario = $_SESSION['usuario']['idUsuario'] ?? null;

if ($acao === '') {
    responderLocalizacao(['sucesso' => false, 'mensagem' => 'Ação não enviada']);
}
if ($tipoUsuario === '' || $idUsuario === null) {
    responderLocalizacao(['sucesso' => false, 'mensagem' => 'Sessão inválida']);
}
if ($tipoUsuario === 'cliente') {
    responderLocalizacao(['sucesso' => false, 'mensagem' => 'clientes não tem acesso a essas ações']);
}

$camposLoc = [
    'loc_id',
    'loc_pro',
    'loc_clin',
    'loc_nome',
    'loc_tipo',
    'loc_cep',
    'loc_num',
    'loc_compl'
];
$camposSala = [
    'sala_id',
    'sala_loc',
    'sala_nome'
];

$tiposLocalizacao = ['clin', 'casa', 'domi'];

function validarCamposLocalizacao($cep, $num, $compl, $nome = null) {
    if (!preg_match('/^[0-9]{8}$/', (string) $cep)) {
        return 'CEP inválido';
    }
    $num = trim((string) $num);
    if ($num === '' || mb_strlen($num) > 5) {
        return 'Número inválido (máximo de 5 caracteres)';
    }
    if (mb_strlen((string) $compl) > 50) {
        return 'Complemento muito longo (máximo de 50 caracteres)';
    }
    if ($nome !== null && (trim($nome) === '' || mb_strlen($nome) > 90)) {
        return 'Nome da localização inválido';
    }
    return null;
}

switch ($acao){
    case "inserirloc":
        $tipo = $_POST['tipo'] ?? '';
        if (!in_array($tipo, $tiposLocalizacao, true)) {
            responderLocalizacao(['sucesso' => false, 'mensagem' => 'Tipo de localização inválido']);
        }
        $erro = validarCamposLocalizacao($_POST['cep'] ?? '', $_POST['numero'] ?? '', $_POST['complemento'] ?? '', $_POST['nome'] ?? '');
        if ($erro) {
            responderLocalizacao(['sucesso' => false, 'mensagem' => $erro]);
        }
        $pro = $tipoUsuario === 'profissional' ? $idUsuario : null;
        $clin = $tipoUsuario === 'clinica' ? $idUsuario : null;
        $localizacao = new localizacao('localizacao',$camposLoc,$camposLoc[0]);
        $inserir = $localizacao->inserirloc($pro, $clin, trim($_POST['nome']), $tipo, $_POST['cep'], trim($_POST['numero']), $_POST['complemento'] ?? '');
        responderLocalizacao($inserir);
    case 'inserirsala':
        $localizacao = new localizacao('sala',$camposSala,$camposSala[0]);
        $inserir = $localizacao->inserirsala($_POST['loc'],$_POST['nome'],$tipoUsuario,$idUsuario);
        responderLocalizacao($inserir);
    case 'pegarloc':
        if (isset($_POST['clinica'])) {
            $id = (int) $_POST['clinica'];
            $dono = 'clinica';
        } else if (isset($_POST['profissional'])) {
            $id = (int) $_POST['profissional'];
            $dono = 'profissional';
        } else {
            $id = $idUsuario;
            $dono = $tipoUsuario;
        }
        if ($dono === 'cliente') {
            responderLocalizacao(['sucesso' => false, 'mensagem' => 'Informe de quem é a localização']);
        }
        $localizacao = new localizacao('localizacao',$camposLoc,$camposLoc[0]);
        $mostrar = $localizacao->pegarloc($dono,$id);
        responderLocalizacao($mostrar);
    case 'pegarSalas':
        $localizacao = new localizacao('sala',$camposSala,$camposSala[0]);
        $mostrar = $localizacao->pegarSalas($_POST['loc']);
        responderLocalizacao($mostrar);
    case 'editarloc':
        $dicpro = [
            'nome' => 'loc_nome',
            'tipo' => 'loc_tipo',
            'CEP' => 'loc_cep',
            'numero' => 'loc_num',
            'compl' => 'loc_compl'
        ];
        $atualizacao = $_POST['atualizacao'] ?? null;
        $valores = $_POST['valores'] ?? null;
        if (!is_array($atualizacao) || !is_array($valores) || count($valores) !== count($atualizacao) + 1) {
            responderLocalizacao(['sucesso' => false, 'mensagem' => 'Dados de atualização inválidos']);
        }
        $campos = ['loc_id'];
        foreach ($atualizacao as $campo){
            if (!array_key_exists($campo, $dicpro)) {
                responderLocalizacao(['sucesso' => false,'mensagem' => 'Campo de atualização não válido']);
            }
            $campos[] = $dicpro[$campo];
        }
        $valores = array_values($valores);
        $mapa = array_combine($campos, $valores);
        if (isset($mapa['loc_cep']) && !preg_match('/^[0-9]{8}$/', (string) $mapa['loc_cep'])) {
            responderLocalizacao(['sucesso' => false, 'mensagem' => 'CEP inválido']);
        }
        if (isset($mapa['loc_num']) && (trim((string) $mapa['loc_num']) === '' || mb_strlen((string) $mapa['loc_num']) > 5)) {
            responderLocalizacao(['sucesso' => false, 'mensagem' => 'Número inválido (máximo de 5 caracteres)']);
        }
        if (isset($mapa['loc_compl']) && mb_strlen((string) $mapa['loc_compl']) > 50) {
            responderLocalizacao(['sucesso' => false, 'mensagem' => 'Complemento muito longo (máximo de 50 caracteres)']);
        }
        if (isset($mapa['loc_tipo']) && !in_array($mapa['loc_tipo'], $tiposLocalizacao, true)) {
            responderLocalizacao(['sucesso' => false, 'mensagem' => 'Tipo de localização inválido']);
        }
        if (isset($mapa['loc_nome']) && (trim((string) $mapa['loc_nome']) === '' || mb_strlen((string) $mapa['loc_nome']) > 90)) {
            responderLocalizacao(['sucesso' => false, 'mensagem' => 'Nome da localização inválido']);
        }
        $localizacao = new localizacao('localizacao',$campos,$campos[0]);
        $mostrar = $localizacao->editar($valores,$tipoUsuario,$idUsuario);
        responderLocalizacao($mostrar);
    case 'removerloc':
        $localizacao = new localizacao('localizacao',$camposLoc,$camposLoc[0]);
        $remover = $localizacao->removerloc($tipoUsuario,$idUsuario,(int) ($_POST['loc'] ?? 0));
        responderLocalizacao($remover);
    case 'editarsala':
        $campos = ['sala_id','sala_nome'];
        $valores = $_POST['valores'] ?? null;
        if (!is_array($valores) || count($valores) !== 2) {
            responderLocalizacao(['sucesso' => false, 'mensagem' => 'Dados de atualização inválidos']);
        }
        $localizacao = new localizacao('sala',$campos,$campos[0]);
        $mostrar = $localizacao->editar(array_values($valores),$tipoUsuario,$idUsuario);
        responderLocalizacao($mostrar);
    default:
        responderLocalizacao(['sucesso' => false, 'mensagem' => 'Ação inválida']);
}
