<?php
use models\servicos;
use models\permissao;
use models\notificacao;
use core\database\DBConnection;


$acao = $_POST['acao'] ?? '';
$servico = new servicos();

switch ($acao){
    case "cadastrar":
        if ($_SESSION['usuario']['tipoUsuario'] === 'clinica') {
            $pro = null;
            $clin = $_SESSION['usuario']['idUsuario'];
        }
        if ($_SESSION['usuario']['tipoUsuario'] === 'profissional') {
            $clin = null;
            $pro = $_SESSION['usuario']['idUsuario'];
        }
        // servico.ser_loc guarda o ID da localização. Vazio (ou "domi") = atendimento na casa do cliente, sem sala.
        $localEnviado = trim((string) ($_POST['loc'] ?? ''));
        $serLoc = null;
        if ($localEnviado !== '' && $localEnviado !== 'domi') {
            if (!ctype_digit($localEnviado)) {
                echo 'Local de atendimento inválido.';
                exit;
            }
            try {
                $pdo = (new DBConnection())->getConn();
                $st = $pdo->prepare("SELECT loc_pro, loc_clin FROM localizacao WHERE loc_id = :loc");
                $st->execute([':loc' => (int) $localEnviado]);
                $local = $st->fetch(\PDO::FETCH_ASSOC);
                $permitido = false;
                if ($local) {
                    if ($pro !== null) {
                        // residência do próprio profissional ou clínica à qual ele está vinculado
                        if ($local['loc_pro'] !== null && (int) $local['loc_pro'] === (int) $pro) {
                            $permitido = true;
                        } elseif ($local['loc_clin'] !== null) {
                            $st = $pdo->prepare("SELECT COUNT(*) FROM profissional_clinica WHERE pc_pro = :pro AND pc_clin = :clin");
                            $st->execute([':pro' => (int) $pro, ':clin' => (int) $local['loc_clin']]);
                            $permitido = (int) $st->fetchColumn() > 0;
                        }
                    } elseif ($local['loc_clin'] !== null && (int) $local['loc_clin'] === (int) $clin) {
                        $permitido = true;
                    }
                }
                if (!$permitido) {
                    echo 'Você não pode cadastrar serviço nesse local.';
                    exit;
                }
                $serLoc = (int) $localEnviado;
            } catch (\Throwable $e) {
                echo 'Erro no banco: ' . $e->getMessage();
                exit;
            }
        }
        $cadastro = $servico->cadastrar(0, $pro ,$clin, $_POST['nome'], $_POST['tipo'], $_POST['desc'], $_POST['dur'], $_POST['inter'], $_POST['val'], $_POST['dia'], $serLoc ?: null);
        echo $cadastro;
        exit;
    case 'MostrarDias':
        if ($_POST['mes']) {
            $dia = '01';
            $mes = $_POST['mes'];  
            $ano = $_POST['ano'];
        }else {
            $hoje = new DateTime();
            $ano = $hoje->format('Y'); 
            $mes = $hoje->format('m'); 
            $dia = $hoje->format('d');
        };
        $mostrar = $servico->MostrarDatas($_SESSION['servico']['ser_id'] ?? '',  $_SESSION['servico']['ser_pro'] ?? $_POST['agnd_pro'] ?? '',$_SESSION['servico']['ser_clin'] ?? $_POST['agnd_clin'] ?? '',$ano,$mes,$dia);
        $_SESSION['datas'] = $mostrar;
        echo $mostrar;
        exit;
    case 'mostrarhorario':
        $mostrar = $servico->PegarHoraVaga($_POST['dia'],$_SESSION['servico']['ser_dur'] ?? $_POST['ser_dur'],$_SESSION['servico']['ser_inter'] ?? $_POST['ser_inter'],$_SESSION['servico']['ser_pro'] ?? $_POST['agnd_pro'],$_SESSION['servico']['ser_clin'] ?? $_POST['agnd_clin']);
        $_SESSION['horarios'] = $mostrar;
        $_SESSION['datas'] = $_POST['dia'];
        echo json_encode($mostrar);
        exit;
    case 'mostrarSala':
        $mostrar = $servico->sala($_POST['inicio'], $_POST['termino'], $_SESSION['servico']['ser_loc'] ?? $_POST['ser_loc'], $_SESSION['datas']);
        echo json_encode($mostrar);        
        exit;
    case 'agendar':
        if (($_SESSION['usuario']['tipoUsuario'] ?? '') === 'profissional' && !empty($_SESSION['servico']['ser_clin'])) {
            $permissao = new permissao('permissoes', 'perm_bin', 'perm_bin');
            $erro = $permissao->permissao( $_SESSION['usuario']['idUsuario'], $_SESSION['servico']['ser_clin'], 1);
            
            if ($erro !== true) {
                echo json_encode($erro);
                exit;
            };
        }
        $cliId = null;
        if ($_SESSION['usuario']['tipoUsuario'] === 'cliente') {
            $cliId = $_SESSION['usuario']['idUsuario'];
        }
        $agendar = $servico->agendar($_SESSION['servico']['ser_pro'],$cliId,$_SESSION['servico']['ser_clin'],$_SESSION['servico']['ser_id'],$_POST['sala'], $_POST['dia'], $_POST['inicio'], $_POST['termino']);
        if($agendar=== 'sucesso'){
            $camposnot= ['notif_id',
                'notif_pd',
                'notif_clin',
                'notif_dest',
                'notif_dtipo',
                'notif_tipo',
                'notif_msg',
                'notif_data',
                'notif_stat'];
            
            if ($_SESSION['usuario']['tipoUsuario'] === 'cliente') {
                $dest = $_SESSION['servico']['ser_pro'];
                $camposnot[] = 'notif_cli';
            }
            else {
                $dest = $_POST['agnd_cli'];
                $camposnot[] = 'notif_pro';
            }
            $notificacao = new notificacao('notificacao', $camposnot, $camposnot[0], $_SESSION['usuario']['idUsuario'], $_SESSION['usuario']['tipoUsuario']);
            $notificacao->enviar(1,$_SESSION['servico']['ser_pro'],'profissional',$_SESSION['servico']['ser_clin']);
            $_SESSION['servico'] = [];
            $_SESSION['datas'] = [];
            $_SESSION['horarios'] = [];
        }
        echo json_encode($agendar);
        exit;
    case 'reagendar':
        if (($_SESSION['usuario']['tipoUsuario'] ?? '') === 'profissional' && !empty($_SESSION['servico']['ser_clin'])) {
            $permissao = new permissao('permissoes', 'perm_bin', 'perm_bin');
            $erro = $permissao->permissao( $_SESSION['usuario']['idUsuario'], $_SESSION['servico']['ser_clin'], 2);
            
            if ($erro !== true) {
                echo json_encode($erro);
                exit;
            };
        }
        $cliId = null;
        if ($_SESSION['usuario']['tipoUsuario'] === 'cliente') {
            $cliId = $_SESSION['usuario']['idUsuario'];
        }
        $reagendar = $servico->reagendar($_POST['agnd_id'],$_POST['agnd_pro'],$cliId,$_POST['ser_id'],$_POST['sala'], $_POST['dia'], $_POST['inicio'], $_POST['termino']);
        if($reagendar=== 'sucesso'){
            $camposnot= ['notif_id',
                'notif_pd',
                'notif_clin',
                'notif_dest',
                'notif_dtipo',
                'notif_tipo',
                'notif_msg',
                'notif_data',
                'notif_stat'];
            
            if ($_SESSION['usuario']['tipoUsuario'] === 'cliente') {
                $dest = $_POST['agnd_pro'];
                $camposnot[] = 'notif_cli';
            }
            else {
                $dest = $_POST['agnd_cli'];
                $camposnot[] = 'notif_pro';
            }
            $notificacao = new notificacao('notificacao', $camposnot, $camposnot[0], $_SESSION['usuario']['idUsuario'], $_SESSION['usuario']['tipoUsuario']);
            $notificacao->enviar(2,$_SESSION['servico']['ser_pro'],'profissional',$_SESSION['servico']['ser_clin']);
            $_SESSION['datas'] = [];
            $_SESSION['horarios'] = [];
        }
        echo json_encode($reagendar);
        exit;
    case 'cancelar':
        if (($_SESSION['usuario']['tipoUsuario'] ?? '') === 'profissional' && !empty($_POST['agnd_clin'])) {
            $permissao = new permissao('permissoes', 'perm_bin', 'perm_bin');
            $erro = $permissao->permissao( $_SESSION['usuario']['idUsuario'], $_POST['agnd_clin'], 3);
            
            if ($erro !== true) {
                echo json_encode($erro);
                exit;
            };
        }
            
        $cancelar = $servico->atentimento($_POST['agnd_pro'], $_POST['agnd_clin'] ?? 0, $_POST['agnd_id'], $_POST['agnd_cli'], $_POST['agnd_ser'],'desmarcado');
        if($cancelar['sucesso'] === true){
            $camposnot= ['notif_id',
                'notif_pd',
                'notif_clin',
                'notif_dest',
                'notif_tipo',
                'notif_dtipo',
                'notif_msg',
                'notif_data',
                'notif_stat'];
            
            if ($_SESSION['usuario']['tipoUsuario'] === 'cliente') {
                $dest = $_POST['agnd_pro'];
                $dtipo = 'profissional';
                $camposnot[] = 'notif_cli';
            }
            else {
                $dest = $_POST['agnd_cli'];
                $dtipo = 'cliente';
                $camposnot[] = 'notif_pro';
            }
            
            $notificacao = new notificacao('notificacao', $camposnot, $camposnot[0], $_SESSION['usuario']['idUsuario'], $_SESSION['usuario']['tipoUsuario']);
            $enviar = $notificacao->enviar(5, $dest,$dtipo,$_POST['agnd_clin'] ?? 0);
            echo json_encode($enviar);
            exit;
        }
        
        echo json_encode($cancelar);
        exit;
    case "atendimento":
        if($_SESSION['usuario']['tipoUsuario'] != 'profissional'){echo json_encode(['sucesso' => false, 'mensagem' => 'somente profissionais podem dizer se o clinte foi atendido ou não compareceu']);}
        $atendimento = $servico->atentimento($_POST['agnd_pro'], $_POST['agnd_clin'] ?? 0, $_POST['agnd_id'], $_POST['agnd_cli'], $_POST['agnd_ser'],$_POST['tipo']);        
        echo json_encode($atendimento);
        exit;
}